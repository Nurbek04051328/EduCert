<template>
  <router-view/>
</template>

<script setup>
  document.title = 'Moyka'
</script>

<style lang="scss">
@import './style/app.scss';
</style>``