<template>
    <head-part :title="title"/>
    <worker-table @edit="handleEdit"/>
    <worker-dialog :title="title" :id="id"/>
</template>

<script setup>
import {ref, onMounted} from 'vue'
import headPart from '../../components/usefull/head-part.vue';
import workerDialog from '../../components/dialog/worker-dialog.vue';
import workerTable from '../../components/table/worker-table.vue';

import { workersStore } from '../../stores/data/workers';

const store = workersStore()
const title = ref('Foydalanuvchi')


onMounted(() => {
    
    store.get_all_workers()
})

const id = ref('')
const handleEdit = (_id) => {
    id.value = _id
}

</script>

<style>

</style>

