<template>
  <div class="auth">
        <div class="box">
            <div class="title">
                Moyka
            </div>
            <el-form 
                @submit.prevent="send"
                label-position="top">
                <el-form-item label="Telefon raqam">
                    <el-input v-model="phone" v-maska data-maska="+998 (##) ###-##-##"/>
                </el-form-item>
            
                <el-form-item label="Parol">
                    <el-input type="password" show-password v-model="password" @keypress.enter="send"/>
                </el-form-item>
                <el-button type="success" @click="send">Kirish</el-button>
            </el-form>
        </div>
    </div>
</template>


<script setup>
import {ref} from 'vue'
import {useUserStore} from '@/stores/main/user'

const userStore = useUserStore()
const phone = ref('')
const password = ref('')

const send = () => {
    userStore.login({
        phone: phone.value,
        password: password.value
    })
}

</script>

<style lang="scss">
@import '@/style/layout/auth.scss';
</style>