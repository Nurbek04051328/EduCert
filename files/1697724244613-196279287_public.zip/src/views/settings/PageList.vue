<template>
    <head-part :title="title"/>
    <page-dialog :title="title" :id="id" />
    <page-table @edit="handleEdit"/>

</template>
<script setup>
import {ref,onMounted} from 'vue'
import headPart from '../../components/usefull/head-part.vue';
import pageDialog from '../../components/dialog/page-dialog.vue'
import pageTable from '../../components/table/page-table.vue';
import { usePagesStore } from '../../stores/data/pages';
const title = ref('Страницы')


const pagesStore = usePagesStore()

onMounted(() => {
    pagesStore.get_all_pages()
})

const id = ref('')
const handleEdit = (_id) => {
    id.value = _id
}


</script>
<style lang="">
    
</style>