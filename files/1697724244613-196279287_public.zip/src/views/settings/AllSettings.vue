<template>
    <head-part :title="title" :btn="false"/>
    <el-menu 
        :router="true"
        mode="horizontal"
        >
      <el-menu-item
        v-for="(item, index) of adminLinks"
        :key="index"
        :index="`/settings/${item.name}`"
        :class="item.class || ''">
        <el-icon><component :is="item.icon" /></el-icon>
        <template #title>{{ item.title }}</template>
      </el-menu-item>
    </el-menu>
    <el-divider/>
    <router-view/>
</template>
<script setup>
import headPart from '../../components/usefull/head-part.vue';
import {ref, onMounted} from 'vue'
import { adminLinks } from '../../stores/menu/admin';
const title = ref('Настройки')

onMounted(() => {



})

</script>
<style lang="">
    
</style>