<template>
    <head-part :title="title">
        <template v-slot:search_form>
            <div class="search mr-1 df align-item-center">
                <el-input 
                    v-model="search.title" 
                    placeholder="Qidiruv" 
                    class="mr-1" 
                    @keypress.enter="findByParam()" 
                    clearable
                    @clear="clearSearch()"
                    />
                <el-button type="success" @click="findByParam()">
                    <el-icon>
                        <Search/>
                    </el-icon>
                </el-button>
                <el-button type="warning" @click="clearSearch()">
                    <el-icon>
                        <close/>
                    </el-icon>
                </el-button>
            </div>
        </template>
    </head-part>
    <washtype-table @edit="handleEdit"/>
    <washtype-dialog :title="title" :id="id"/>
</template>

<script setup>
import {ref, onMounted} from 'vue'
import headPart from '@/components/usefull/head-part.vue';
import washtypeDialog from '@/components/boss/washtype/washtype-dialog.vue';
import washtypeTable from '@/components/boss/washtype/washtype-table.vue';

import { washtypesStore } from '@/stores/data/washtypes';

const store = washtypesStore()
const title = ref('Moyka turi')

const search = ref({})

const clearSearch = () => {
    search.value = {}
    findByParam()
}

const findByParam = () => {
    store.get_all_washtypes({...search.value})
}

onMounted(() => {
    store.get_all_washtypes()
})

const id = ref('')
const handleEdit = (_id) => {
    id.value = _id
}

</script>

<style>

</style>

