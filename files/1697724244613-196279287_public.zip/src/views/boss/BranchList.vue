<template>
    <head-part :title="title">
        <template v-slot:search_form>
            <div class="search mr-1 df align-item-center">
                <el-input 
                    v-model="search.title" 
                    placeholder="Qidiruv" 
                    class="mr-1" 
                    @keypress.enter="findByParam()" 
                    clearable
                    @clear="clearSearch()"
                    />
                <el-button type="success" @click="findByParam()">
                    <el-icon>
                        <Search/>
                    </el-icon>
                </el-button>
                <el-button type="warning" @click="clearSearch()">
                    <el-icon>
                        <close/>
                    </el-icon>
                </el-button>
            </div>
        </template>
    </head-part>
    <branch-table @edit="handleEdit"/>
    <branch-dialog :title="title" :id="id"/>
</template>

<script setup>
import {ref, onMounted} from 'vue'
import headPart from '@/components/usefull/head-part.vue';
import branchDialog from '@/components/boss/branch/branch-dialog.vue';
import branchTable from '@/components/boss/branch/branch-table.vue';

import { branchsStore } from '@/stores/data/branchs';

const store = branchsStore()
const title = ref('Filial')

const search = ref({})

const clearSearch = () => {
    search.value = {}
    findByParam()
}

const findByParam = () => {
    store.get_all_branchs({...search.value})
}

onMounted(() => {
    store.get_all_branchs()
})

const id = ref('')
const handleEdit = (_id) => {
    id.value = _id
}

</script>

<style>

</style>

