<template>
    <head-part :title="title">
        <template v-slot:search_form>
            <div class="search mr-1 df align-item-center">
                <el-input 
                    v-model="search.title" 
                    placeholder="Qidiruv" 
                    class="mr-1" 
                    @keypress.enter="findByParam()" 
                    clearable
                    @clear="clearSearch()"
                    />
                <el-button type="success" @click="findByParam()">
                    <el-icon>
                        <Search/>
                    </el-icon>
                </el-button>
                <el-button type="warning" @click="clearSearch()">
                    <el-icon>
                        <close/>
                    </el-icon>
                </el-button>
            </div>
        </template>
    </head-part>
    <cartype-table @edit="handleEdit"/>
    <cartype-dialog :title="title" :id="id"/>
</template>

<script setup>
import {ref, onMounted} from 'vue'
import headPart from '@/components/usefull/head-part.vue';
import cartypeDialog from '@/components/boss/cartype/cartype-dialog.vue';
import cartypeTable from '@/components/boss/cartype/cartype-table.vue';

import { cartypesStore } from '@/stores/data/cartypes';

const store = cartypesStore()
const title = ref('Mashina turi')

const search = ref({})

const clearSearch = () => {
    search.value = {}
    findByParam()
}

const findByParam = () => {
    store.get_all_cartypes({...search.value})
}

onMounted(() => {
    store.get_all_cartypes()
})

const id = ref('')
const handleEdit = (_id) => {
    id.value = _id
}

</script>

<style>

</style>

