<template>
  <div class="head mb-2">
    <div class="df align-item-center">
      <el-button 
        v-if="back"
        class="mr-1"
        @click="$router.push(back)">
        <el-icon>
          <back/>
        </el-icon>
      </el-button>
      <h1>{{ title }}lar</h1>
    </div>
    
    <div class="df align-item-center">
      <slot name="search_form"/>
      <el-button 
      v-if="btn"
        type="primary"
        @click="setToggle(true)"
        >
        <el-icon class="mr-1">
            <plus/>
        </el-icon>
        Yangi {{ title?.toLowerCase() }}
    </el-button>
    </div>
  </div>
</template>

<script setup>
import { useUsefull } from '../../stores/component/usefull';
const usefullStore = useUsefull()
const {setToggle} = usefullStore


defineProps({
    title: String,
    btn: {
      type:Boolean,
      default:true
    },
    back: String
})

</script>

<style>

</style>