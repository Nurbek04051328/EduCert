<template lang="">
    <el-table :data="contracts">
        <el-table-column type="index" :index="indexFunc" width="60" />
        <el-table-column label="№ догора" prop="num" min-width="120"/>
        <el-table-column label="Поставшик" prop="purveyor.title" min-width="120"/>
        <el-table-column width="60" align="right">
            <template #default="scope">
                <div>
                    <el-button 
                        @click="change_status(scope.row._id)"
                        :type="scope.row.status == 0 ? 'danger' : 'success'">
                        <el-icon>
                            <close v-if="scope.row.status == 0"/>
                            <check v-else/>
                        </el-icon>
                    </el-button>
                </div>
            </template>
        </el-table-column>
        <el-table-column width="80" align="right">
            <template #default="scope">
                <el-dropdown>
                    <el-button>
                        <el-icon class="el-icon--right">
                            <more />
                        </el-icon>
                    </el-button>
                    <template #dropdown>
                        <el-dropdown-menu>
                            <el-dropdown-item @click="editContract(scope.row._id)">
                                <el-icon>
                                    <Edit/>
                                </el-icon>
                                O'zgartirish
                            </el-dropdown-item>
                            
                            <el-dropdown-item @click="remove(scope.row._id)">
                                <el-icon>
                                    <delete/>
                                </el-icon>
                                O'chirish
                            </el-dropdown-item>
                        </el-dropdown-menu>
                    </template>
                </el-dropdown>
            </template>
        </el-table-column>
    </el-table>
    <el-pagination
        v-if="contractsCount > contractSize"
        background
        layout="Oldingi, contractr, Keyingi"
        @current-change="handleCurrentChange"
        :contract-size="contractSize"
        :total="contractsCount">
    </el-pagination>
</template>

<script setup>
const props = defineProps([
    'search'
])
const emit = defineEmits(['edit'])
import { storeToRefs } from 'pinia';
import { useContractsStore } from '../../stores/data/contract';
import { ref } from 'vue'
import { useUsefull } from '../../stores/component/usefull';

const contract = ref(1)
const contractSize = ref(30)

const store = useContractsStore()
const {contracts,contractsCount} = storeToRefs(store)

const {get_all_contracts,delete_contract,status_contract} = store

const indexFunc = (index) => (contract.value-1)*contractSize.value + index + 1

const handleCurrentChange = (val) => {
    window.scrollTo(0, 0)
    this.$router.push({ path: '/contract', query: { next: val } })

    get_all_contracts({ next: val, ...props.search.value })
    contract.value = val;
}

const remove = (_id) => {
    if (confirm('Qaroringiz qat`iymi?')){
        delete_contract(_id)
    }
}


const usefullStore = useUsefull()

const editContract = (_id) => {
    emit('edit',_id)
    usefullStore.setEditToggle(true)
}

const change_status = (_id) => {
    status_contract(_id)
}

</script>
<style lang="">
    
</style>