<template lang="">
    <el-table :data="workers">
        <el-table-column type="index" :index="indexFunc" width="60" />
        <el-table-column label="Ism-familiyasi" prop="name" min-width="160">
            <template #default="scope">
                <div class="df align-item-center">
                    <el-image 
                    style="width: 50px; height: 50px" 
                    class="mr-1"
                    :src="`${api.url}/${scope.row.avatar[0]?.response}`" fit="cover" />
                    {{scope.row.lname}} {{scope.row.name}}
                </div>
            </template>

        </el-table-column>
        <el-table-column label="Telefon raqami" prop="phone" min-width="120"/>
        <el-table-column label="Login" prop="login"/>
        <el-table-column label="Tizim roli" prop="role"/>
        <el-table-column width="60" align="right">
            <template #default="scope">
                <div>
                    <el-button 
                        @click="change_status(scope.row._id)"
                        :type="scope.row.status == 0 ? 'danger' : 'success'">
                        <el-icon>
                            <close v-if="scope.row.status == 0"/>
                            <check v-else/>
                        </el-icon>
                    </el-button>
                </div>
            </template>
        </el-table-column>
        
        <el-table-column width="80" align="right">
            <template #default="scope">
                <el-dropdown>
                    <el-button>
                        <el-icon class="el-icon--right">
                            <more />
                        </el-icon>
                    </el-button>
                    <template #dropdown>
                        <el-dropdown-menu>
                            <el-dropdown-item @click="editUser(scope.row._id)">
                                <el-icon>
                                    <Edit/>
                                </el-icon>
                                O'zgartirish
                            </el-dropdown-item>
                            
                            <el-dropdown-item @click="remove(scope.row._id)">
                                <el-icon>
                                    <delete/>
                                </el-icon>
                                O'chirish
                            </el-dropdown-item>
                        </el-dropdown-menu>
                    </template>
                </el-dropdown>
            </template>
        </el-table-column>
    </el-table>
    <el-pagination
        v-if="workersCount > pageSize"
        background
        layout="Oldingi, pager, Keyingi"
        @current-change="handleCurrentChange"
        :page-size="pageSize"
        :total="workersCount">
    </el-pagination>
</template>

<script setup>
const props = defineProps([
    'search'
])
const emit = defineEmits(['edit'])
import { storeToRefs } from 'pinia';
import { workersStore } from '../../stores/data/workers';
import { apiStore } from '../../stores/helpers/axios';
import {ref} from 'vue'
import { useUsefull } from '../../stores/component/usefull';

const api = apiStore()

const page = ref(1)
const pageSize = ref(30)

const store = workersStore()
const {workers,workersCount} = storeToRefs(store)

const {get_all_workers,delete_worker,status_worker} = store

const indexFunc = (index) => (page.value-1)*pageSize.value + index + 1

const handleCurrentChange = (val) => {
    window.scrollTo(0, 0)
    this.$router.push({ path: '/worker', query: { next: val } })

    get_all_workers({ next: val, ...props.search.value })
    page.value = val;
}

const remove = (_id) => {
    if (confirm('Qaroringiz qat`iymi?')){
        delete_worker(_id)
    }
}


const usefullStore = useUsefull()

const editUser = (_id) => {
    emit('edit',_id)
    usefullStore.setEditToggle(true)
}

const change_status = (_id) => {
    status_worker(_id)
}

</script>
<style lang="">
    
</style>