<template>
  <el-dialog
    v-model="usefullStore.toggle"
    :title="`Yangi ${title.toLowerCase()}`"
    width="40%"
    :before-close="handleClose"
  >
    <el-form
      :model="page"
      :rules="rules"
      name="form"
      ref="form"
      label-position="top"
      @submit.prevent="add(form)"
    >
      <el-form-item class="input left" label="Sahifa nomi" prop="title">
        <el-input v-model="page.title" />
      </el-form-item>
      <el-form-item class="input left" label="Qisqa nomi" prop="slug">
        <el-input :disabled="false" v-model="page.slug" />
      </el-form-item>
      <el-form-item class="input left" label="Tartib raqami">
        <el-input-number :controls="false" v-model="page.order" />
      </el-form-item>

      <el-row v-for="(crud, index) of page.cruds" :key="index" :gutter="30">
        <el-col :span="12">
          <el-form-item class="input left" label="Amal nomi">
            <el-input v-model="crud.title" @input="addCrud()" />
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item class="input left" @input="addCrud()" label="Qisqa nomi">
            <el-input v-model="crud.slug" :disabled="false" />
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>

    <template #footer>
      <span class="dialog-footer">
        <el-button @click="handleClose">Bekor qilish</el-button>
        <el-button type="primary" :disabled="check" @click="add(form)"> Saqlash </el-button>
      </span>
    </template>
  </el-dialog>
</template>

<script setup>
import { ref, watch } from 'vue'
import { storeToRefs } from 'pinia'
import { useUsefull } from '../../stores/component/usefull'
import { usePagesStore } from '../../stores/data/pages'
import { ElMessage } from 'element-plus';

const props = defineProps(['title', 'id'])
const check = ref(false)
const form = ref()
const rules = ref({
    title: [{ required: true, message: 'Sahifa nomini kiriting' }],
    slug: [{ required: true, message: 'Sahifa qisqa matnini kiriting' }]
})
const page = ref({
    cruds:[{
        title:'',
        slug:''
    }]
})

const usefullStore = useUsefull()
const pagesStore = usePagesStore()

const handleClose = () => {
  page.value = {
    cruds:[{
        title:'',
        slug:''
    }]
  }
  usefullStore.setToggle(false)
  usefullStore.setEditToggle(false)
}

const add = async (formEl) => {
  if (!formEl) return
  await formEl.validate((valid) => {
    if (valid) {
      page.value.cruds = page.value.cruds.filter(crud => crud.title.length >= 1 && crud.slug.length >= 1) 
      if (editToggle.value) {
        pagesStore.update_page(page.value)
      } else {
        pagesStore.add_new_page(page.value)
      }
      handleClose()
    } else {
        ElMessage.warning('Заполните полей!')
        console.clear()
    }
  })
}

const addCrud = () =>{
    if (page.value.cruds.at(-1).title.length >= 3 && page.value.cruds.at(-1).slug.length >= 3){
        page.value.cruds.push({
            title:'',
            slug:''
        })
    }
}

const { editToggle } = storeToRefs(usefullStore)
watch(editToggle, async () => {
  if (editToggle.value) {
    let res = await pagesStore.get_page(props.id)
    if (res.status == 200) {
      page.value = { ...res.data }
      usefullStore.setToggle(true)
    }
  }
})
</script>

<style></style>
