<template>
    <el-dialog v-model="usefullStore.toggle" title="Новый договор" width="90%" :before-close="handleClose">
        <el-form :model="contract" :rules="rules" name="form" ref="form" label-position="top" @submit.prevent="add(form)">
            <el-row :gutter="30">
                <el-col :span="8">
                    <el-form-item class="input" label="Номер договора" prop="num">
                        <el-input-number :controls="false" v-model="contract.num" />
                    </el-form-item>
                </el-col>
                <el-col :span="8">
                    <el-form-item class="input left" label="Поставшик" prop="purveyor">
                        <el-select v-model="contract.purveyor" placeholder="Выберите из списка">
                            <el-option 
                            v-for="item in purveyorList" 
                            :key="item._id" 
                            :label="item.title" 
                            :value="item._id" 
                            />
                        </el-select>
                    </el-form-item>
                </el-col>
                <el-col :span="8">
                    <el-form-item label="Дата прихода" prop="data">
                        <el-date-picker
                            v-model="contract.data"
                            type="date"
                            placeholder="Выберите дату"
                        />
                    </el-form-item>
                </el-col>
                <el-col :span="24">
                    <el-form-item label="Файл договора" prop="file">
                        <el-upload 
                            :file-list="contract.file" 
                            class="upload-demo"
                            :action="`${varStore.url}/files/contract`" 
                            :headers="tokenStore.headerToken"
                            multiple
                            :on-remove="handleRemove">
                            <el-button type="primary">Загрузить файл контракта</el-button>
                        </el-upload>
                    </el-form-item>
                </el-col>
            </el-row>
            <el-row 
                v-for="doc, index of contract.document"
                :key="index"
                :gutter="30"
                >
                <el-col :span="4">
                    <el-form-item class="input" :label="index == 0 ? 'Категория товара' : ''">
                        <el-select 
                            @change="selectBugsubcategory(doc.bugcategory,index)" 
                            v-model="doc.bugcategory" placeholder="Выберите из списка">
                            <el-option 
                            v-for="item in bugcategoryList" 
                            :key="item._id" 
                            :label="item.title" 
                            :value="item._id" 
                            />
                        </el-select>
                    </el-form-item>
                </el-col>
                <el-col :span="4">
                    <el-form-item class="input" :label="index == 0 ? 'Подкатегория товара' : ''">
                        <el-select 
                            @change="addDoc()"
                            v-model="doc.bugsubcategory" placeholder="Выберите из списка">
                            <el-option 
                            v-for="item in doc.bugsubcategoryList" 
                            :key="item._id" 
                            :label="item.title" 
                            :value="item._id" 
                            />
                        </el-select>
                    </el-form-item>
                </el-col>
                <el-col :span="4">
                    <el-form-item class="input" :label="index == 0 ? 'Название товара' : ''">
                        <el-input v-model="doc.title" @input="addDoc()"/> 
                    </el-form-item>
                </el-col>
                <el-col :span="4">
                    <el-form-item class="input" :label="index == 0 ? 'Сумма одного товара' : ''">
                        <el-input-number :controls="false" class="input" @input="addDoc()" v-model="doc.summa">
                            <template #append>
                                сум
                            </template>
                        </el-input-number>
                    </el-form-item>
                </el-col>
                <el-col :span="4">
                    <el-form-item class="input" :label="index == 0 ? 'Количество товара' : ''">
                        <el-input-number @input="addDoc()" :controls="false" class="input" v-model="doc.count"/>
                    </el-form-item>
                </el-col>
                <el-col :span="4">
                    <el-form-item :label="index === 0 ? 'Итого' : ''">
                        {{ (doc.count * doc.summa * (1 + contract.nds / 100)).toLocaleString() }} сум
                    </el-form-item>
                </el-col>

            </el-row>
            <el-divider />
            <el-form-item label="НДС">
                <el-input-number v-model="contract.nds" :controls="false"/>
            </el-form-item>


        </el-form>
        <template #footer>
            <span class="dialog-footer">
                <el-button @click="handleClose">Отменить</el-button>
                <el-button type="primary" :disabled="check" @click="add(form)"> Сохранить </el-button>
            </span>
        </template>
    </el-dialog>
</template>
  
<script setup>
import { ref, watch, computed } from 'vue'
import { storeToRefs } from 'pinia'
import { useUsefull } from '../../stores/component/usefull'
import { useContractsStore } from '../../stores/data/contract'
import { usePurveyorsStore } from '../../stores/data/purveyor'
import { useVarStore } from '../../stores/helpers/vars'
import { useBugcategorysStore} from '../../stores/data/bugcategory'
import { useBugsubcategorysStore} from '../../stores/data/bugsubcategory'
import { useTokenStore } from '../../stores/main/token' 
import { ElMessage } from 'element-plus'
const props = defineProps(['title', 'id'])
const check = ref(false)
const form = ref()
const rules = ref({
    title: [{ required: true, message: 'Напишите наименование поставшика' }],
    purveyor: [{ required: true, message: 'Выберите Поставшика', trigger: 'change' }],
    address: [{ required: true, message: 'Напишите адрес поставшика' }],
    check: [{ required: true, message: 'Напишите ЧЕК поставшика' }],
    bank: [{ required: true, message: 'Напишите БАНК поставшика' }],
    mfo: [{ required: true, message: 'Напишите МФО поставшика' }],
    inn: [{ required: true, message: 'Напишите ИНН поставшика' }],
    director: [{ required: true, message: 'Напишите имя-фамилия директор поставшика' }],
})
const contract = ref({
    nds:12,
    document: [
        {
            bugcategory: '',
            bugsubcategory: '',
            bugsubcategoryList: [],
            title: '',
            summa: 0,
            count: 0,
            sum: 0
        }
    ]
})

const usefullStore = useUsefull()
const contractsStore = useContractsStore()
const purveyorStore = usePurveyorsStore()
const varStore = useVarStore()
const bugcategoryStore = useBugcategorysStore()
const bugsubcategoryStore = useBugsubcategorysStore()
const tokenStore = useTokenStore()
const bugcategoryList = computed(() => {
    return bugcategoryStore.bugcategorys.filter(cat => cat.status == 1)
})

const selectBugsubcategory = async (_id,index) => {
    let res = await bugsubcategoryStore.get_bugsubcategory_list(_id)
    if (res.status === 200) {
        contract.value.document[index].bugsubcategoryList = [...res.data.bugCategory.bugsubcategory.filter(cat => cat.status == 1)]
    }
}

const addDoc = () => {
    if (contract.value.document.at(-1).title && contract.value.document.at(-1).bugcategory && contract.value.document.at(-1).bugsubcategory && contract.value.document.at(-1).count && contract.value.document.at(-1).summa){
        contract.value.document.push( {
            bugcategory: '',
            bugsubcategory: '',
            bugsubcategoryList: [],
            title: '',
            summa: 0,
            count: 0,
            sum: 0
        })
    }
}

const purveyorList = computed(() => {
    return purveyorStore.purveyors.filter(org => org.status == 1)
})


const handleClose = () => {
    contract.value = {}
    usefullStore.setToggle(false)
    usefullStore.setEditToggle(false)
}

const add = async (formEl) => {
    if (!formEl) return
    await formEl.validate((valid) => {
        if (valid) {
            if (editToggle.value)
                contractsStore.update_contract(contract.value)
            else
                contractsStore.add_new_contract(contract.value)

            handleClose()
        } else {
            ElMessage.warning('Заполните полей!')
            console.clear()
        }
    })
}

const handleRemove = (file) => {
    console.log(file)
}




const { editToggle } = storeToRefs(usefullStore)
watch(editToggle, async () => {
    if (editToggle.value) {
        let res = await contractsStore.get_contract(props.id)
        if (res.status == 200) {
            contract.value = { ...res.data }
            usefullStore.setToggle(true)
        }
    }
})
</script>
  
<style></style>
  