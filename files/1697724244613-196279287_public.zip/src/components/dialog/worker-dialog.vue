<template>
  <el-dialog
    v-model="usefullStore.toggle"
    :title="`Yangi ${title.toLowerCase()}`"
    width="50%"
    :before-close="handleClose"
  >
    <el-form
      :model="worker"
      :rules="rulesList"
      name="form"
      ref="form"
      label-position="top"
      @submit.prevent="add(form)"
    >
      <el-row :gutter="30">
        <el-col :span="12" :xs="24">
          <el-form-item label="Telefon raqam" prop="phone">
            <el-input v-model="worker.phone" @blur="checkLogin()" v-maska data-maska="+998 (##) ###-##-##" />
          </el-form-item>
        </el-col>
        <el-col :span="12" :xs="24">
          <el-form-item label="Mahfiy kalit" prop="password">
            <el-input v-model="worker.password" type="password" show-password />
          </el-form-item>
        </el-col>
        <el-col :span="8" :xs="24">
          <el-form-item label="Familiya" prop="lname">
            <el-input v-model="worker.lname" />
          </el-form-item>
        </el-col>
        <el-col :span="8" :xs="24">
          <el-form-item label="Ism" prop="name">
            <el-input v-model="worker.name" />
          </el-form-item>
        </el-col>
        <el-col :span="8" :xs="24">
          <el-form-item label="Tizim rollari" prop="role">
            <el-select 
                v-model="worker.role" 
                class="m-2 full" 
                placeholder="Ro'yhatdan tanlang">
                <el-option
                v-for="item,index in store.roleList"
                :key="index"
                :label="item"
                :value="item"
                />
            </el-select>
        </el-form-item>
        </el-col>
        <el-col :span="12" :xs="24">
          <el-form-item label="Rasm faylini yuklang">
            <el-upload
              class="ml"
              v-model:file-list="worker.avatar"
              :action="`${url}/helper/upload`"
              
              list-type="picture-card"
              :limit="1"
              :on-preview="handlePictureCardPreview"
              :on-remove="handleRemove"
              :before-upload="beforeUp"
              :on-success="handleSuccess"
              :headers="headerToken"
            >
              <el-icon>
                <Plus />
              </el-icon>
            </el-upload>
            <el-dialog v-model="dialogVisible">
              <img w-full :src="dialogImageUrl" alt="Foydalanuvchi rasmi" />
            </el-dialog>
          </el-form-item>
          <el-alert
            v-show="fileError"
            title="Faylning hajmi 5 mb dan oshmasligi lozim"
            type="error"
          />
        </el-col>
      </el-row>
    </el-form>

    <template #footer>
      <span class="dialog-footer">
        <el-button @click="handleClose">Bekor qilish</el-button>
        <el-button
          type="primary"
          :disabled="check"
          @click="add(form)"
        >
          Saqlash
        </el-button>
      </span>
    </template>
  </el-dialog>
</template>

<script setup>
import { ref, watch, computed } from 'vue'
import { storeToRefs } from 'pinia'
import { ElMessage } from 'element-plus'
import { useUsefull } from '../../stores/component/usefull'
import { apiStore } from '../../stores/helpers/axios'
import { workersStore } from '../../stores/data/workers'
import { useTokenStore } from '../../stores/main/token'

const props = defineProps(['title', 'id'])
const check = ref(false)
const form = ref()
const rules = ref({
  password: [{ required: true, message: 'Parol kiritilmagan!', trigger: 'blur' }],
  name: [{ required: true, message: 'Ism kiritilmagan!', trigger: 'blur' }],
  lname: [{ required: true, message: 'Familiya kiritilmagan!', trigger: 'blur' }],
  phone: [{ required: true, message: 'Telefon raqam kiritilmagan!', trigger: 'blur' }],
  role: [{ required: true, message: 'Foydalanuvchiga tizim roli belgilanmadi!', trigger: 'blur' }]
})
const worker = ref({})

const usefullStore = useUsefull()
const tokenStore = useTokenStore()
const store = workersStore()



const { headerToken } = storeToRefs(tokenStore)


const handleClose = () => {
  worker.value = {}
  usefullStore.setToggle(false)
  usefullStore.setEditToggle(false)
}

const add = async (formEl) => {
  if (!formEl) return
  await formEl.validate((valid) => {
    if (valid) {
      if (editToggle.value) {
        store.update_worker(worker.value)
      } else {
        store.add_new_worker(worker.value)
      }
      handleClose()
    } else {
      ElMessage.warning('Заполните полей!!')
        console.clear()
    }
  })
}

const dialogImageUrl = ref('')
const dialogVisible = ref(false)
const handlePictureCardPreview = (file) => {
  dialogImageUrl.value = file.url
  dialogVisible.value = true
}

const checkLogin = async () => {
  let result = await store.checkLogin({ phone: worker.value.phone })
  if (result.status == 200) {
    console.log(result.data)
    if (result.data.message == 'not busy') check.value = false

    if (result.data.message == 'exists') {
      check.value = true
      ElMessage({
        type: 'warning',
        message: 'Пользователь с таким логином уже есть!'
      })
    }
  }
}

const handleSuccess = file => {
  console.log(file);
}

const fileError = ref(false)
const beforeUp = (file) => {
  if (file.size / 1024 / 1024 > 5) {
    fileError.value = true
    return false
  } else fileError.value = false
}

const api = apiStore()
const {url} = storeToRefs(api)
const handleRemove = (file) => {
  api.post({
    url: 'helper/remove',
    data: file
  })
}

const { editToggle } = storeToRefs(usefullStore)
watch(editToggle, async () => {
  if (editToggle.value){
    let res = await store.get_worker(props.id)
    if (res.status == 200) {
      console.log(res.data)
      if (res.data.avatar) {
        res.data.avatar[0].url = `${url.value}/${res.data.avatar[0].response}`
      }
      worker.value = { ...res.data }
      usefullStore.setToggle(true)
    }
  }
})

const rulesList = computed(() => {
  let r = {...rules.value}
  if (editToggle.value){
    delete r.password
  }
  return {...r}
})

</script>

<style></style>
