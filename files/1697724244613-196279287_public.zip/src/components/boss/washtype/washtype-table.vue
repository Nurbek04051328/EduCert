<template>
    <el-table :data="washtypes">
        <el-table-column type="index" :index="indexFunc" width="60" />
        <el-table-column label="Nomi">
            <template #default="scope">
                <div>                    
                    {{ scope.row.translates.find(tr => tr.language == 'uz').title || '' }}
                </div>
            </template>
        </el-table-column>        
        <el-table-column label="Название">
            <template #default="scope">
                <div>                    
                    {{ scope.row.translates.find(tr => tr.language == 'ru').title || '' }}
                </div>
            </template>
        </el-table-column>        
        <el-table-column width="60" align="right">
            <template #default="scope">
                <div>
                    <el-button 
                        @click="change_status(scope.row._id)"
                        :type="scope.row.status == 0 ? 'danger' : 'success'">
                        <el-icon>
                            <close v-if="scope.row.status == 0"/>
                            <check v-else/>
                        </el-icon>
                    </el-button>
                </div>
            </template>
        </el-table-column>
        
        <el-table-column width="80" align="right">
            <template #default="scope">
                <el-dropdown>
                    <el-button>
                        <el-icon class="el-icon--right">
                            <more />
                        </el-icon>
                    </el-button>
                    <template #dropdown>
                        <el-dropdown-menu>
                            <el-dropdown-item @click="editUser(scope.row._id)">
                                <el-icon>
                                    <Edit/>
                                </el-icon>
                                O'zgartirish
                            </el-dropdown-item>
                            
                            <el-dropdown-item @click="remove(scope.row._id)">
                                <el-icon>
                                    <delete/>
                                </el-icon>
                                O'chirish
                            </el-dropdown-item>
                        </el-dropdown-menu>
                    </template>
                </el-dropdown>
            </template>
        </el-table-column>
    </el-table>
    <el-pagination
        v-if="washtypesCount > pageSize"
        background
        layout="Oldingi, pager, Keyingi"
        @current-change="handleCurrentChange"
        :page-size="pageSize"
        :total="washtypesCount">
    </el-pagination>
</template>

<script setup>
const props = defineProps([
    'search'
])
const emit = defineEmits(['edit'])
import { storeToRefs } from 'pinia';
import { washtypesStore } from '@/stores/data/washtypes';
import { apiStore } from '@/stores/helpers/axios';
import {ref} from 'vue'
import { useUsefull } from '@/stores/component/usefull';

const api = apiStore()

const page = ref(1)
const pageSize = ref(30)

const store = washtypesStore()
const {washtypes,washtypesCount} = storeToRefs(store)

const {get_all_washtypes,delete_washtype,status_washtype} = store

const indexFunc = (index) => (page.value-1)*pageSize.value + index + 1

const handleCurrentChange = (val) => {
    window.scrollTo(0, 0)
    this.$router.push({ path: '/washtype', query: { next: val } })

    get_all_washtypes({ next: val, ...props.search.value })
    page.value = val;
}

const remove = (_id) => {
    if (confirm('Qaroringiz qat`iymi?')){
        delete_washtype(_id)
    }
}


const usefullStore = useUsefull()

const editUser = (_id) => {
    emit('edit',_id)
    usefullStore.setEditToggle(true)
}

const change_status = (_id) => {
    status_washtype(_id)
}

</script>
<style lang="">
    
</style>