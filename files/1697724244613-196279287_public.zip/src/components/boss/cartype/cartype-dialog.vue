<template>
    <el-dialog
      v-model="usefullStore.toggle"
      :title="`Yangi ${title.toLowerCase()}`"
      width="500px"
      :before-close="handleClose"
    >
      <el-form
        :model="cartype"
        name="form"
        ref="form"
        label-position="top"
        @submit.prevent="add(form)"
      >
        <el-tabs v-model="lang">
          <el-tab-pane 
            v-for="trans,index of cartype.translates"
            :key="index"
            :label="languages[index]" 
            :name="languages[index]">
              <el-form-item 
                :label="index == 0 ? 'Mashina turi nomi' : 'Название тип машин'" 
                :rules="index == 0 ? [
                  { required:true, message:'Mashuna turi yozilmagan' }
                ] : []">
                <el-input v-model="trans.title" />
              </el-form-item>
          </el-tab-pane>
        </el-tabs>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="handleClose">Bekor qilish</el-button>
          <el-button
            type="primary"            
            @click="add(form)"
          >
            Saqlash
          </el-button>
        </span>
      </template>
    </el-dialog>
  </template>
  
  <script setup>
  import { ref, watch, computed } from 'vue'
  import { storeToRefs } from 'pinia'
  import { ElMessage } from 'element-plus'
  import { useUsefull } from '@/stores/component/usefull'
  import { apiStore } from '@/stores/helpers/axios'
  import { cartypesStore } from '@/stores/data/cartypes'
  import { languages } from '@/utils/env'

  const lang = ref('uz')
  const props = defineProps(['title', 'id'])
  const check = ref(false)
  const form = ref()
  
  const cartype = ref({
    translates:[...languages.map(l => {
      return {
        language:l,
        title:'',
      }
    })]
  })
  
  const usefullStore = useUsefull()
  const store = cartypesStore()
  
  
  

  
  
  const handleClose = () => {
    cartype.value = {
      translates:[...languages.map(l => {
      return {
        language:l,
        title:'',
      }
    })]
    }
    usefullStore.setToggle(false)
    usefullStore.setEditToggle(false)
    lang.value = 'uz'
  }
  
  const add = async (formEl) => {
    if (!formEl) return
    await formEl.validate((valid) => {
      if (valid) {
        console.log(cartype.value);
        cartype.value.phone = '+998 ' + cartype.value.phone 
        if (editToggle.value) {
          store.update_cartype(cartype.value)
        } else {          
          store.add_new_cartype(cartype.value)
        }
        handleClose()
      } else {
        ElMessage.warning('Заполните полей!!')
          console.clear()
      }
    })
  }
  

  
  const { editToggle } = storeToRefs(usefullStore)
  watch(editToggle, async () => {
    if (editToggle.value){
      console.log(props.id);
      let res = await store.get_cartype(props.id)
      if (res.status == 200) {                
        cartype.value = { ...res.data }
        usefullStore.setToggle(true)
      }
    }
  })
  
  const rulesList = computed(() => {
    let r = {...rules.value}
    if (editToggle.value){
      delete r.password
    }
    return {...r}
  })
  
  </script>
  
  <style></style>
  