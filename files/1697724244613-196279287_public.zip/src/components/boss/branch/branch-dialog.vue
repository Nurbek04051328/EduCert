<template>
    <el-dialog
      v-model="usefullStore.toggle"
      :title="`Yangi ${title.toLowerCase()}`"
      width="500px"
      :before-close="handleClose"
    >
      <el-form
        :model="branch"
        :rules="rulesList"
        name="form"
        ref="form"
        label-position="top"
        @submit.prevent="add(form)"
      >
        
        <el-form-item label="Filial telefon raqami">
          <el-input v-model="branch.phone"  v-maska data-maska="(##) ###-##-##">
            <template #prepend>+998</template>
          </el-input>
        </el-form-item>
        <el-form-item label="Filial yandex mapdagi lokatsiyasi">
          <el-input v-model="branch.loc" @input="getMap"/>
          <a href="https://yandex.com/maps/" target="_blank" class="link">Yandex map</a>
        </el-form-item>
        <el-tabs v-model="lang">
          <el-tab-pane 
            v-for="trans,index of branch.translates"
            :key="index"
            :label="languages[index]" 
            :name="languages[index]">
              <el-form-item 
                :label="index == 0 ? 'Filial nomi' : 'Название филиала'" 
                :rules="index == 0 ? [
                  { required:true, message:'Filial nomi kiritilmagan' }
                ] : []">
                <el-input v-model="trans.title" />
              </el-form-item>
              <el-form-item 
                :label="index == 0 ? 'Manzil' : 'Адрес'"
                :rules="index == 0 ? [
                  { required:true, message:'Filial manzilini kiritilmagan' }
                ] : []"
                >
                <el-input 
                v-model="trans.address" 
                
                />
              </el-form-item>
            
              <el-form-item 
                :label="index == 0 ? 'Ish vaqti' : 'Время работы'"
                :rules="index == 0 ? [
                  { required:true, message:'Ish vaqtini nomi kiritilmagan' }
                ] : []"
                >
                <el-input 
                v-model="trans.workTime"  
                :placeholder="index == 0 ? '9:00 dan 22:00 gacha' : 'с 9:00 до 22:00'"
                
                />
              </el-form-item>
          
          </el-tab-pane>
          
        </el-tabs>
        
      </el-form>
  
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="handleClose">Bekor qilish</el-button>
          <el-button
            type="primary"
            :disabled="check"
            @click="add(form)"
          >
            Saqlash
          </el-button>
        </span>
      </template>
    </el-dialog>
  </template>
  
  <script setup>
  import { ref, watch, computed } from 'vue'
  import { storeToRefs } from 'pinia'
  import { ElMessage } from 'element-plus'
  import { useUsefull } from '@/stores/component/usefull'
  import { apiStore } from '@/stores/helpers/axios'
  import { branchsStore } from '@/stores/data/branchs'
  import { languages } from '@/utils/env'
  const lang = ref('uz')
  const props = defineProps(['title', 'id'])
  const check = ref(false)
  const form = ref()
  const rules = ref({
    title: [{ required: true, message: 'Filial nomi kiritilmagan!', trigger: 'blur' }],
    address: [{ required: true, message: 'Filial manzili kiritilmagan!', trigger: 'blur' }],
    workTime: [{ required: true, message: 'Filial ish vaqti kiritilmagan!', trigger: 'blur' }],    
  })
  const branch = ref({
    translates:[...languages.map(l => {
      return {
        language:l,
        title:'',
        workTime:'',
        address:''
      }
    })]
  })

  
  
  const usefullStore = useUsefull()
  const store = branchsStore()
  
  
  
  
  const handleClose = () => {
    branch.value = {
      translates:[...languages.map(l => {
      return {
        language:l,
        title:'',
        workTime:'',
        address:''
      }
    })]
    }
    usefullStore.setToggle(false)
    usefullStore.setEditToggle(false)
    lang.value = 'uz'
  }
  
  const add = async (formEl) => {
    if (!formEl) return
    await formEl.validate((valid) => {
      if (valid) {
        console.log(branch.value);
        branch.value.phone = '+998 ' + branch.value.phone 
        if (editToggle.value) {
          store.update_branch(branch.value)
        } else {          
          store.add_new_branch(branch.value)
        }
        handleClose()
      } else {
        ElMessage.warning('Заполните полей!!')
          console.clear()
      }
    })
  }


  const api = apiStore()
  const {url} = storeToRefs(api)


  const getMap = () => {
    let map = new URLSearchParams(branch.value.loc)
    let point = Object.fromEntries(map.entries())['whatshere[point]'] || null 
    if (point){      
      point = point.split(',')
      branch.value.lon = point[0] || ''
      branch.value.lat = point[1] || ''      
    }    
  }
  
  const { editToggle } = storeToRefs(usefullStore)
  watch(editToggle, async () => {
    if (editToggle.value){
      console.log(props.id);
      let res = await store.get_branch(props.id)
      if (res.status == 200) {                
        branch.value = { ...res.data }
        usefullStore.setToggle(true)
      }
    }
  })
  
  const rulesList = computed(() => {
    let r = {...rules.value}
    if (editToggle.value){
      delete r.password
    }
    return {...r}
  })
  
  </script>
  
  <style></style>
  