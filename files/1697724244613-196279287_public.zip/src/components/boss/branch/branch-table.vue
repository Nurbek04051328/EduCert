<template>
    <el-table :data="branchs">
        <el-table-column type="index" :index="indexFunc" width="60" />
        <el-table-column label="Nomi">
            <template #default="scope">
                <div>                    
                    {{ scope.row.translates.find(tr => tr.language == 'uz').title || '' }}
                </div>
            </template>
        </el-table-column>
        <el-table-column label="Manzil">
            <template #default="scope">
                <div>                    
                    {{ scope.row.translates.find(tr => tr.language == 'uz').address || '' }}
                </div>
            </template>
        </el-table-column>
        <el-table-column label="Telefon raqam" prop="phone"/>
        <el-table-column label="Lokatsiya">
            <template #default="scope">
                <div>
                    <a :href="scope.row.loc" target="_blank" class="el-button">
                        <el-icon>
                            <location/>
                        </el-icon>
                    </a>
                </div>
            </template>
        </el-table-column>
        <el-table-column width="60" align="right">
            <template #default="scope">
                <div>
                    <el-button 
                        @click="change_status(scope.row._id)"
                        :type="scope.row.status == 0 ? 'danger' : 'success'">
                        <el-icon>
                            <close v-if="scope.row.status == 0"/>
                            <check v-else/>
                        </el-icon>
                    </el-button>
                </div>
            </template>
        </el-table-column>
        
        <el-table-column width="80" align="right">
            <template #default="scope">
                <el-dropdown>
                    <el-button>
                        <el-icon class="el-icon--right">
                            <more />
                        </el-icon>
                    </el-button>
                    <template #dropdown>
                        <el-dropdown-menu>
                            <el-dropdown-item @click="editUser(scope.row._id)">
                                <el-icon>
                                    <Edit/>
                                </el-icon>
                                O'zgartirish
                            </el-dropdown-item>
                            
                            <el-dropdown-item @click="remove(scope.row._id)">
                                <el-icon>
                                    <delete/>
                                </el-icon>
                                O'chirish
                            </el-dropdown-item>
                        </el-dropdown-menu>
                    </template>
                </el-dropdown>
            </template>
        </el-table-column>
    </el-table>
    <el-pagination
        v-if="branchsCount > pageSize"
        background
        layout="Oldingi, pager, Keyingi"
        @current-change="handleCurrentChange"
        :page-size="pageSize"
        :total="branchsCount">
    </el-pagination>
</template>

<script setup>
const props = defineProps([
    'search'
])
const emit = defineEmits(['edit'])
import { storeToRefs } from 'pinia';
import { branchsStore } from '@/stores/data/branchs';
import { apiStore } from '@/stores/helpers/axios';
import {ref} from 'vue'
import { useUsefull } from '@/stores/component/usefull';

const api = apiStore()

const page = ref(1)
const pageSize = ref(30)

const store = branchsStore()
const {branchs,branchsCount} = storeToRefs(store)

const {get_all_branchs,delete_branch,status_branch} = store

const indexFunc = (index) => (page.value-1)*pageSize.value + index + 1

const handleCurrentChange = (val) => {
    window.scrollTo(0, 0)
    this.$router.push({ path: '/branch', query: { next: val } })

    get_all_branchs({ next: val, ...props.search.value })
    page.value = val;
}

const remove = (_id) => {
    if (confirm('Qaroringiz qat`iymi?')){
        delete_branch(_id)
    }
}


const usefullStore = useUsefull()

const editUser = (_id) => {
    emit('edit',_id)
    usefullStore.setEditToggle(true)
}

const change_status = (_id) => {
    status_branch(_id)
}

</script>
<style lang="">
    
</style>