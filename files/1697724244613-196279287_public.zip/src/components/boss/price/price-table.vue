<template>
    <el-table :data="prices">
        <el-table-column type="index" :index="indexFunc" width="60" />
        <el-table-column label="Kuzov turi">
            <template #default="scope">
                <div>                    
                    {{ scope.row.carType?.title }}
                </div>
            </template>
        </el-table-column>        
        <el-table-column label="Moyka turi">
            <template #default="scope">
                <div>                    
                    {{ scope.row.washType?.title }}
                </div>
            </template>
        </el-table-column>
        <el-table-column label="Filial" prop="branch.title" />
        <el-table-column label="Narhi">
            <template #default="scope">
                <div>
                    {{scope.row.price.toLocaleString()}} so'm
                </div>
            </template>
        </el-table-column>
        <el-table-column width="60" align="right">
            <template #default="scope">
                <div>
                    <el-button 
                        @click="change_status(scope.row._id)"
                        :type="scope.row.status == 0 ? 'danger' : 'success'">
                        <el-icon>
                            <close v-if="scope.row.status == 0"/>
                            <check v-else/>
                        </el-icon>
                    </el-button>
                </div>
            </template>
        </el-table-column>        
        <el-table-column width="80" align="right">
            <template #default="scope">
                <el-dropdown>
                    <el-button>
                        <el-icon class="el-icon--right">
                            <more />
                        </el-icon>
                    </el-button>
                    <template #dropdown>
                        <el-dropdown-menu>
                            <el-dropdown-item @click="editUser(scope.row._id)">
                                <el-icon>
                                    <Edit/>
                                </el-icon>
                                O'zgartirish
                            </el-dropdown-item>
                            
                            <el-dropdown-item @click="remove(scope.row._id)">
                                <el-icon>
                                    <delete/>
                                </el-icon>
                                O'chirish
                            </el-dropdown-item>
                        </el-dropdown-menu>
                    </template>
                </el-dropdown>
            </template>
        </el-table-column>
    </el-table>
    <el-pagination
        v-if="pricesCount > pageSize"
        background
        layout="Oldingi, pager, Keyingi"
        @current-change="handleCurrentChange"
        :page-size="pageSize"
        :total="pricesCount">
    </el-pagination>
</template>

<script setup>
const props = defineProps([
    'search'
])
const emit = defineEmits(['edit'])
import { storeToRefs } from 'pinia';
import { pricesStore } from '@/stores/data/prices';
import { apiStore } from '@/stores/helpers/axios';
import {ref} from 'vue'
import { useUsefull } from '@/stores/component/usefull';

const api = apiStore()

const page = ref(1)
const pageSize = ref(30)

const store = pricesStore()
const {prices,pricesCount} = storeToRefs(store)

const {get_all_prices,delete_price,status_price} = store

const indexFunc = (index) => (page.value-1)*pageSize.value + index + 1

const handleCurrentChange = (val) => {
    window.scrollTo(0, 0)
    this.$router.push({ path: '/price', query: { next: val } })

    get_all_prices({ next: val, ...props.search.value })
    page.value = val;
}

const remove = (_id) => {
    if (confirm('Qaroringiz qat`iymi?')){
        delete_price(_id)
    }
}


const usefullStore = useUsefull()

const editUser = (_id) => {
    emit('edit',_id)
    usefullStore.setEditToggle(true)
}

const change_status = (_id) => {
    status_price(_id)
}

</script>
<style lang="">
    
</style>