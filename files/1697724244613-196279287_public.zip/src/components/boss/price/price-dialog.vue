<template>
    <el-dialog
      v-model="usefullStore.toggle"
      :title="`Yangi ${title.toLowerCase()}`"
      width="500px"
      :before-close="handleClose"
    >
      <el-form
        :model="price"
        name="form"
        ref="form"
        label-position="top"
        @submit.prevent="add(form)"
      >
        <el-form-item label="Filial" class="input left">
          <el-select 
            v-model="branch" 
            class="m-2" 
            placeholder="Ro'yhatdan tanlang"
            :multiple="!editToggle"
            >
            <el-option
              v-for="item in branchs.branchs"
              :key="item._id"
              :label="item.translates.find(tr => tr.language == 'uz').title || ''"
              :value="item._id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="Mashina turi" class="input left">
          <el-select 
            v-model="cartype" 
            class="m-2" 
            placeholder="Ro'yhatdan tanlang"
            
            >
            <el-option
              v-for="item in cartypes.cartypes"
              :key="item._id"
              :label="item.translates.find(tr => tr.language == 'uz').title || ''"
              :value="item._id"
            />
          </el-select>
        </el-form-item>
        <el-row
          v-if="!editToggle"
          v-for="item,index of price"
          :key="index"
          :gutter="20"
        >
          <el-col :span="12">
            <el-form-item class="input" :label="index == 0 ? 'Moyka turi' : ''">
                <el-input v-model="item.washtype_title" :disabled="true"/> 
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item class="input" :label="index == 0 ? 'Narhi' : ''">
              <el-input v-model="item.price"  
                v-maska
                data-maska="0.99"
                data-maska-tokens="0:\d:multiple|9:\d:optional"> 
                <template #append>so'm</template>
              </el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row v-else>
          <el-col :span="12">
            <el-form-item label="Moyka turi">
              <el-select 
                v-model="washtype" 
                class="m-2" 
                placeholder="Ro'yhatdan tanlang"
                
                >
                <el-option
                  v-for="item in washtypes"
                  :key="item._id"
                  :label="item.translates.find(tr => tr.language == 'uz').title || ''"
                  :value="item._id"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item class="input" label="Narhi">
              <el-input v-model="money"  
                v-maska
                data-maska="0.99"
                data-maska-tokens="0:\d:multiple|9:\d:optional"> 
                <template #append>so'm</template>
              </el-input>
            </el-form-item>
          </el-col>
        </el-row>
        
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="handleClose">Bekor qilish</el-button>
          <el-button
            type="primary"            
            @click="add(form)"
          >
            Saqlash
          </el-button>
        </span>
      </template>
    </el-dialog>
  </template>
  
  <script setup>
  import { ref, watch, computed } from 'vue'
  import { storeToRefs } from 'pinia'
  import { ElMessage } from 'element-plus'
  import { useUsefull } from '@/stores/component/usefull'
  import { apiStore } from '@/stores/helpers/axios'
  
  import { pricesStore } from '@/stores/data/prices'
  import { cartypesStore } from '@/stores/data/cartypes'
  import { washtypesStore } from '@/stores/data/washtypes'
  import { branchsStore } from '@/stores/data/branchs'

  const props = defineProps(['title', 'id'])
  const check = ref(false)
  const form = ref()


  
  const price = ref([])
  const branch = ref([])
  const cartype = ref('')
  const washtype = ref('')
  const money = ref(0)
  const editID = ref('')

  const usefullStore = useUsefull()
  const store = pricesStore()
  const cartypes = cartypesStore()
  const washtypesSt = washtypesStore()
  const {washtypes} = storeToRefs(washtypesSt)

  const branchs = branchsStore()
  
  const handleClose = () => {
    price.value = washtypes.value.map(washtype => {
      return {
        washtype: washtype._id,
        washtype_title: washtype.translates.find(tr => tr.language == 'uz').title || '',
        price: ''
      }
    })
    cartype.value = ''
    branch.value = []
    money.value = 0
    editID.value = ''
    washtype.value = ''

    usefullStore.setToggle(false)
    usefullStore.setEditToggle(false)    
  }
  
  const add = async (formEl) => {
    if (!formEl) return
    await formEl.validate((valid) => {
      if (valid) {
        price.value = price.value.map(p => {

          return {
            branch: [...branch.value],
            carType: cartype.value,
            washType: p.washtype,
            price: +p.price
          }
        })
        // console.log(price.value);
        if (editToggle.value) {
          store.update_price({
            _id: editID.value,
            price: money.value,
            washType: washtype.value,
            carType: cartype.value,
            branch: branch.value
          })
        } else {          
          store.add_new_price(price.value)
        }
        handleClose()
      } else {
        ElMessage.warning('Maydonlarni to`ldiring!!')
          console.clear()
      }
    })
  }
  

  
  const { editToggle } = storeToRefs(usefullStore)
  watch(editToggle, async () => {
    if (editToggle.value){
      console.log(props.id);
      let res = await store.get_price(props.id)
      if (res.status == 200) {           
        console.log(res.data);  
        editID.value = res.data._id   
        money.value = res.data.price
        washtype.value = res.data.washType
        cartype.value = res.data.carType
        branch.value = res.data.branch
        // price.value = { ...res.data }
        usefullStore.setToggle(true)
      }
    }
  })

  watch(washtypes,() => {
    if (washtypes.value){
      price.value = washtypes.value.map(washtype => {

        return {
          washtype: washtype._id,
          washtype_title: washtype.translates.find(tr => tr.language == 'uz').title || '',
          price: ''
        }
      })
      console.log(washtypes.value);
    }
  })
  
  const rulesList = computed(() => {
    let r = {...rules.value}
    if (editToggle.value){
      delete r.password
    }
    return {...r}
  })
  
  </script>
  
  <style></style>
  