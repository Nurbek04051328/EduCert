<template>
  <header class="header">
    <div class="logo">
      <img src="@/assets/logo.png" alt="">
        Moyka
    </div>

    <nav class="navbar">
      <router-link to="/dashboard">
        <span>Bosh sahifa</span>
      </router-link>
      <router-link
        v-for="(item, index) of menu"
        :key="index"
        :index="`/${item.name}`"
        :class="item.class || ''"
        :to="item.path"
        >        
        {{ item.meta?.title }}
      </router-link>
    </nav>
    <div class="profile">
      <div class="name">{{ user.name }}</div>
      <button @click="logout">
        <el-icon>
          <switch-button/>
        </el-icon>
      </button>
    </div>    
  </header>
</template>

<script setup>
import { useUserStore } from '../../stores/main/user';
import { useUsefull } from '../../stores/component/usefull';
import { useMenuStore } from '../../stores/menu'
import { storeToRefs } from 'pinia';



const menuStore = useMenuStore()
const { menu } = storeToRefs(menuStore)

const userStore = useUserStore()
const usefull = useUsefull()
const {user} = storeToRefs(userStore)
const {navToggle} = storeToRefs(usefull)
const {setNavToggle} = usefull

const logout = () => {
    if (confirm('Вы уверены?')){
        
        userStore.exit()
    }
}

</script>

<style lang="scss">
@import '@/style/layout/header.scss';
@import '@/style/layout/navbar.scss';
</style>