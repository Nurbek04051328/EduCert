
import { createRouter, createWebHistory } from 'vue-router'
import { useUserStore } from '../stores/main/user'

import { adminLinks } from '../stores/menu/admin';
import { bossLinks } from '../stores/menu/boss';

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      redirect: '/dashboard',
      component: () => import('@/layout/mainLayout.vue'),
      children: [
        {
          path: '/dashboard',
          name: 'dashboard',
          component: () => import('@/views/homePage.vue'),
          meta: {
            title: 'Bosh sahifa',
          }
        },
        ...adminLinks,
        ...bossLinks
      ]
    },
    {
      path:'/',
      component: () => import('@/layout/authLayout.vue'),
      children: [
        {
          path: '/login',
          name: 'login',
          component: () => import ('@/views/auth/loginPage.vue'),
          meta: {
            title: 'Tizimga kirish',
          }
        }
      ]
    }
  ]
})

router.beforeEach((to,from,next)=>{
  if (to.name == 'login') 
    next()
  else {
    const userStore = useUserStore()
    userStore.checkUser()
    document.title = `Moyka | ${to.meta?.title || ''}`
    next()
  }
})

export default router
