<template>
  <div class="app">
    <div class="wrapper">
      <header-part/>
      <div class="main">
        <router-view/>
      </div>
    </div>
  </div>

</template>

<script setup>
import headerPart from "../components/layout/header-part.vue"


</script>

<style lang="scss">
@import '@/style/layout/main.scss';
</style>