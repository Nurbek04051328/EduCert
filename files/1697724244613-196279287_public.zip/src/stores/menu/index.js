import { defineStore } from "pinia";
import {ref} from 'vue'

import { adminMenu } from "./admin";
import { bossMenu } from "./boss";

export const useMenuStore = defineStore('menu',()=>{
    
    const menu = ref([])
    const setMenu = (role) => {
        switch (role){
            case 'admin': 
                menu.value = [...adminMenu] 
                break
            case 'boss':
                menu.value = [...bossMenu]
        }
    }
    return {
        menu,
        setMenu
    }
})