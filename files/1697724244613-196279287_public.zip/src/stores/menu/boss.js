export const bossMenu = [
    {
        path:'/branch',
        name:'branch',
        component: () => import('@/views/boss/BranchList.vue'),
        icon: 'list',
        meta: {
            title: 'Filiallar',
            role: ['boss']
        }
    },
    {
        path:'/cartype',
        name:'cartype',
        component: () => import('@/views/boss/CartypeList.vue'),
        icon: 'list',
        meta: {
            title: 'Mashina turlari',
            role: ['boss']
        }
    },
    {
        path:'/washtype',
        name:'washtype',
        component: () => import('@/views/boss/WashtypeList.vue'),
        icon: 'list',
        meta: {
            title: 'Moyka turlari',
            role: ['boss']
        }
    },
    {
        path:'/price',
        name:'price',
        component: () => import('@/views/boss/PriceList.vue'),
        icon: 'list',
        meta: {
            title: 'Narhlar',
            role: ['boss']
        }
    }
]


export const bossLinks = [
    ...bossMenu
]