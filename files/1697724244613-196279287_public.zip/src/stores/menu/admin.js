export const adminMenu = [
    {
        path:'/workers',
        name:'workers',
        component: () => import('@/views/user/AllWorkers.vue'),
        icon: 'user',
        meta: {
            title: 'Foydalanuvchilar',
            role: ['admin']
        }
    },
    // {
    //     path:'/settings',
    //     name: 'settings',
    //     component: () => import('@/views/settings/AllSettings.vue'),
    //     icon: 'setting',
    //     class:'mt-a',
    //     meta: {
    //         title:'Sozlamalar',
    //     },
    //     children: [
    //         // {
    //         //     path:'roles',
    //         //     name: 'roles',
    //         //     component: () => import('@/views/settings/RoleList.vue'),
    //         //     icon: 'user',
    //         //     meta: {
    //         //         title:'Роли',   
    //         //     },     
    //         // },
            
    //     ]
        
    // }
] 


export const adminLinks = [
    ...adminMenu
]
