import { defineStore } from "pinia";
import {ref} from 'vue'

export const useUsefull = defineStore('usefull',()=>{

    const toggle = ref(false)
    const setToggle = (payload) => {
        toggle.value = payload
    }

    const editToggle = ref(false)
    const setEditToggle = (payload) => {
        editToggle.value = payload
    }

    const navToggle = ref(true)
    const setNavToggle = (val) => {

        navToggle.value = val
    }

    return {
        toggle,
        setToggle,

        editToggle,
        setEditToggle,

        navToggle,
        setNavToggle
    }
})