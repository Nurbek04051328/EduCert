import {defineStore} from 'pinia'
import {ref} from 'vue'

import { apiStore } from '../helpers/axios'
import { ElMessage } from 'element-plus'

export const workersStore = defineStore('workers',()=>{
    const workers = ref([])
    const workersCount = ref(0)
    const api = apiStore()
    const roleList = ref(['boss','manager','worker'])

    const get_all_workers = async (search) => {
        let result = await api.get({url:'worker',search})
        if (result.status === 200){
            console.log(result.data)
            workers.value = result.data.users
            workersCount.value = result.data.count
        }
    }

    const add_new_worker = async (data) => {
        let result = await api.post({url:'worker',data})
        if (result.status === 201){
            workers.value = [data,...workers.value]
            ElMessage({
                type:'success',
                message: 'Yangi foydalanuvchi qo`shildi'
            })
        }
    }

    const get_worker = async (_id) => {
        return await api.get({url:`worker/${_id}`})
    }

    const update_worker = async (data) => {
        console.log(data)
        let result = await api.put({url:'worker',data})
        console.log(result.data,result.status)
        if (result.status === 200){
            workers.value = workers.value.map((worker) => {
                if (worker._id == result.data._id) return result.data
                return worker
            })
            ElMessage({
                type:'success',
                message: 'Foydalanuvchi ma`lumoti yangilandi'
            })
        }
    }

    const status_worker = async (_id) => {
        api.get({url:`worker/status/${_id}`})
        .then(res=> {
            console.log(res.data)
            workers.value = workers.value.map(worker => {
                if (worker._id == _id) return {
                    ...worker,
                    status: worker.status == 0 ? 1 : 0
                }
                return worker
            })
            ElMessage({
                type:'success',
                message:'Foydalanuvchi holati o`zgartirildi'
            })
        })
    }

    const delete_worker = async (_id) => {
        let result = await api.remove({url:`worker/${_id}`})
        if (result.status === 200){
            workers.value = workers.value.filter(worker => {
                if (worker._id == _id) return false
                return worker
            })
            ElMessage.warning('Foydalanuvchi o`chilrildi')
        }
    }

    const checkLogin = async (data) => {
        console.log(data)
        return await api.post({url:'worker/find',data})
    }

    return {
        roleList,
        workers,
        workersCount,
        status_worker,
        get_all_workers,
        add_new_worker,
        get_worker,
        delete_worker,
        update_worker,
        checkLogin
    }

})