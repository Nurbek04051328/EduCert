import {defineStore} from 'pinia'
import {ref} from 'vue'

import { apiStore } from '../helpers/axios'
import { ElMessage } from 'element-plus'

export const cartypesStore = defineStore('cartypes',()=>{
    const cartypes = ref([])
    const cartypesCount = ref(0)
    const api = apiStore()

    const get_all_cartypes = async (search) => {
        let result = await api.get({url:'cartype',search})
        if (result.status === 200){
            cartypes.value = result.data.carTypes
            cartypesCount.value = result.data.count
        }
    }

    const add_new_cartype = async (data) => {
        console.log(data)
        let result = await api.post({url:'cartype',data})
        if (result.status === 201){
            cartypes.value = [result.data,...cartypes.value]
            ElMessage({
                type:'success',
                message: 'Yangi mashina turi qo`shildi'
            })
        }
    }

    const get_cartype = async (_id) => {
        return await api.get({url:`cartype/${_id}`})
    }

    const update_cartype = async (data) => {
        console.log(data)
        let result = await api.put({url:'cartype',data})
        console.log(result.data,result.status)
        if (result.status === 200){
            console.log(result.data)
            cartypes.value = cartypes.value.map((cartype) => {
                if (cartype._id == result.data._id) return result.data
                return cartype
            })
            ElMessage({
                type:'success',
                message: 'Mashina turi ma`lumoti yangilandi'
            })
        }
    }

    const status_cartype = async (_id) => {
        api.get({url:`cartype/status/${_id}`})
        .then(res=> {
            console.log(res.data)
            cartypes.value = cartypes.value.map(cartype => {
                if (cartype._id == _id) return {
                    ...cartype,
                    status: cartype.status == 0 ? 1 : 0
                }
                return cartype
            })
            ElMessage({
                type:'success',
                message:'Mashina turi holati o`zgartirildi'
            })
        })
    }

    const delete_cartype = async (_id) => {
        let result = await api.remove({url:`cartype/${_id}`})
        if (result.status === 200){
            cartypes.value = cartypes.value.filter(cartype => {
                if (cartype._id == _id) return false
                return cartype
            })
            ElMessage.warning('Mashina turi o`chilrildi')
        }
    }

    const checkLogin = async (data) => {
        console.log(data)
        return await api.post({url:'cartype/find',data})
    }

    return {
        cartypes,
        cartypesCount,
        status_cartype,
        get_all_cartypes,
        add_new_cartype,
        get_cartype,
        delete_cartype,
        update_cartype,
        checkLogin
    }

})