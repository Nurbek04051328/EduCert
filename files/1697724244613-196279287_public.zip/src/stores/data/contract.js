import {defineStore} from 'pinia'
import {ref} from 'vue'

import { apiStore } from '../helpers/axios'
import { ElMessage } from 'element-plus'

export const useContractsStore = defineStore('contracts',()=>{
    const contracts = ref([])
    const contractsCount = ref(0)
    const api = apiStore()

    const get_all_contracts = async (search) => {
        let result = await api.getAxios({url:'contract',search})
        if (result.status === 200){
            contracts.value = [...result.data.contracts]
            contractsCount.value = result.data.count
        }
    }

    const add_new_contract = async (data) => {
        let result = await api.postAxios({url:'contract',data})

        if (result.status === 201){
            contracts.value = [result.data,...contracts.value]
            ElMessage({
                type:'success',
                message: 'Добавлено'
            })
        }
    }

    const get_contract = async (_id) => {
        return await api.getAxios({url:`contract/${_id}`})
    }

    const update_contract = async (data) => {
        let result = await api.putAxios({url:'contract',data})
        if (result.status === 200){
            contracts.value = contracts.value.map((contract) => {
                if (contract._id == result.data._id) return result.data
                return contract
            })
            ElMessage({
                type:'success',
                message: 'Обновлено'
            })
        }
    }

    const status_contract = async (_id) => {
        await api.getAxios({url:`contract/change/${_id}`})
        .then(()=> {
            contracts.value = contracts.value.map(contract => {
                if (contract._id == _id) return {
                    ...contract,
                    status: contract.status == 0 ? 1 : 0
                }
                return contract
            })
            ElMessage({
                type:'success',
                message:'Статус изменено'
            })
        })
    }

    const delete_contract = async (_id) => {
        let result = await api.deleteAxios({url:`contract/${_id}`})
        if (result.status === 200){
            contracts.value = contracts.value.filter(contract => {
                if (contract._id == _id) return false
                return contract
            })
            ElMessage.warning('Удалено')
        }
    }


    return {
        contracts,
        contractsCount,
        status_contract,
        get_all_contracts,
        add_new_contract,
        get_contract,
        delete_contract,
        update_contract,
    }

})