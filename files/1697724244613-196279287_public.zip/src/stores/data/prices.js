import {defineStore} from 'pinia'
import {ref} from 'vue'

import { apiStore } from '../helpers/axios'
import { ElMessage } from 'element-plus'

export const pricesStore = defineStore('prices',()=>{
    const prices = ref([])
    const pricesCount = ref(0)
    const api = apiStore()
    

    const get_all_prices = async (search) => {
        let result = await api.get({url:'price',search})
        if (result.status === 200){
            prices.value = result.data.prices
            pricesCount.value = result.data.count
        }
    }

    const add_new_price = async (data) => {
        let result = await api.post({url:'price',data})
        if (result.status === 201){
            prices.value = [...result.data.success,...prices.value]
            if (result.data.warning.length > 0){
                let war = ''
                result.data.warning.forEach(item => {
                    ElMessage({
                        type:'warning',
                        message: `${item.branch?.title} filialga ${item.carType?.title} mashina turiga "${item.washType?.title}" moyka turiga narh belgilangan.`,
                        duration: 6000
                    })
                })
                console.log(result.data.warning)
            }
            if (result.data.success.length > 0){
                ElMessage({
                    type:'success',
                    message: 'Yangi narh qo`shildi'
                })
            }
        }
    }

    const get_price = async (_id) => {
        return await api.get({url:`price/${_id}`})
    }

    const update_price = async (data) => {
        console.log(data)
        let result = await api.put({url:'price',data})
        console.log(result.data,result.status)
        if (result.status === 200){
            console.log(result.data)
            prices.value = prices.value.map((price) => {
                if (price._id == result.data._id) return result.data
                return price
            })
            ElMessage({
                type:'success',
                message: 'Narh ma`lumoti yangilandi'
            })
        }
    }

    const status_price = async (_id) => {
        api.get({url:`price/status/${_id}`})
        .then(res=> {
            console.log(res.data)
            prices.value = prices.value.map(price => {
                if (price._id == _id) return {
                    ...price,
                    status: price.status == 0 ? 1 : 0
                }
                return price
            })
            ElMessage({
                type:'success',
                message:'Narh holati o`zgartirildi'
            })
        })
    }

    const delete_price = async (_id) => {
        let result = await api.remove({url:`price/${_id}`})
        if (result.status === 200){
            prices.value = prices.value.filter(price => {
                if (price._id == _id) return false
                return price
            })
            ElMessage.warning('Narh o`chilrildi')
        }
    }

    const checkLogin = async (data) => {
        console.log(data)
        return await api.post({url:'price/find',data})
    }

    return {
        prices,
        pricesCount,
        status_price,
        get_all_prices,
        add_new_price,
        get_price,
        delete_price,
        update_price,
        checkLogin
    }

})