import {defineStore} from 'pinia'
import {ref} from 'vue'

import { apiStore } from '../helpers/axios'
import { ElMessage } from 'element-plus'

export const branchsStore = defineStore('branchs',()=>{
    const branchs = ref([])
    const branchsCount = ref(0)
    const api = apiStore()
    const roleList = ref(['boss','manager','branch'])

    const get_all_branchs = async (search) => {
        let result = await api.get({url:'branch',search})
        if (result.status === 200){
            branchs.value = result.data.branch
            branchsCount.value = result.data.count
        }
    }

    const add_new_branch = async (data) => {
        console.log(data)
        let result = await api.post({url:'branch',data})
        if (result.status === 201){
            branchs.value = [result.data,...branchs.value]
            ElMessage({
                type:'success',
                message: 'Yangi filial qo`shildi'
            })
        }
    }

    const get_branch = async (_id) => {
        return await api.get({url:`branch/${_id}`})
    }

    const update_branch = async (data) => {
        console.log(data)
        let result = await api.put({url:'branch',data})
        console.log(result.data,result.status)
        if (result.status === 200){
            console.log(result.data)
            branchs.value = branchs.value.map((branch) => {
                if (branch._id == result.data._id) return result.data
                return branch
            })
            ElMessage({
                type:'success',
                message: 'Filial ma`lumoti yangilandi'
            })
        }
    }

    const status_branch = async (_id) => {
        api.get({url:`branch/status/${_id}`})
        .then(res=> {
            console.log(res.data)
            branchs.value = branchs.value.map(branch => {
                if (branch._id == _id) return {
                    ...branch,
                    status: branch.status == 0 ? 1 : 0
                }
                return branch
            })
            ElMessage({
                type:'success',
                message:'Filial holati o`zgartirildi'
            })
        })
    }

    const delete_branch = async (_id) => {
        let result = await api.remove({url:`branch/${_id}`})
        if (result.status === 200){
            branchs.value = branchs.value.filter(branch => {
                if (branch._id == _id) return false
                return branch
            })
            ElMessage.warning('Filial o`chilrildi')
        }
    }

    const checkLogin = async (data) => {
        console.log(data)
        return await api.post({url:'branch/find',data})
    }

    return {
        roleList,
        branchs,
        branchsCount,
        status_branch,
        get_all_branchs,
        add_new_branch,
        get_branch,
        delete_branch,
        update_branch,
        checkLogin
    }

})