import {defineStore} from 'pinia'
import {ref} from 'vue'

import { apiStore } from '../helpers/axios'
import { ElMessage } from 'element-plus'

export const washtypesStore = defineStore('washtypes',()=>{
    const washtypes = ref([])
    const washtypesCount = ref(0)
    const api = apiStore()

    const get_all_washtypes = async (search) => {
        let result = await api.get({url:'washtype',search})
        if (result.status === 200){
            washtypes.value = result.data.washTypes
            washtypesCount.value = result.data.count
        }
    }

    const add_new_washtype = async (data) => {
        console.log(data)
        let result = await api.post({url:'washtype',data})
        if (result.status === 201){
            washtypes.value = [result.data,...washtypes.value]
            ElMessage({
                type:'success',
                message: 'Yangi moyka turi qo`shildi'
            })
        }
    }

    const get_washtype = async (_id) => {
        return await api.get({url:`washtype/${_id}`})
    }

    const update_washtype = async (data) => {
        console.log(data)
        let result = await api.put({url:'washtype',data})
        console.log(result.data,result.status)
        if (result.status === 200){
            console.log(result.data)
            washtypes.value = washtypes.value.map((washtype) => {
                if (washtype._id == result.data._id) return result.data
                return washtype
            })
            ElMessage({
                type:'success',
                message: 'Moyka turi ma`lumoti yangilandi'
            })
        }
    }

    const status_washtype = async (_id) => {
        api.get({url:`washtype/status/${_id}`})
        .then(res=> {
            console.log(res.data)
            washtypes.value = washtypes.value.map(washtype => {
                if (washtype._id == _id) return {
                    ...washtype,
                    status: washtype.status == 0 ? 1 : 0
                }
                return washtype
            })
            ElMessage({
                type:'success',
                message:'Moyka turi holati o`zgartirildi'
            })
        })
    }

    const delete_washtype = async (_id) => {
        let result = await api.remove({url:`washtype/${_id}`})
        if (result.status === 200){
            washtypes.value = washtypes.value.filter(washtype => {
                if (washtype._id == _id) return false
                return washtype
            })
            ElMessage.warning('Moyka turi o`chilrildi')
        }
    }

    const checkLogin = async (data) => {
        console.log(data)
        return await api.post({url:'washtype/find',data})
    }

    return {
        washtypes,
        washtypesCount,
        status_washtype,
        get_all_washtypes,
        add_new_washtype,
        get_washtype,
        delete_washtype,
        update_washtype,
        checkLogin
    }

})