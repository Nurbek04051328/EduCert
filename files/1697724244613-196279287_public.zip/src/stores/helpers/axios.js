import {ref} from 'vue'
import {defineStore, storeToRefs} from 'pinia'
import axios from 'axios'

import {useTokenStore} from '../main/token'
import { useLoadingStore } from '../main/loading'
import { ElMessage } from 'element-plus'

import router from '../../router'

export const apiStore = defineStore('apiStore',()=>{
    
    const url = ref('http://95.130.227.69:3006')

    const tokenStore = useTokenStore()
    const {token} = storeToRefs(tokenStore)

    const loadingStore = useLoadingStore()
    

    const get = async (payload) => {
        loadingStore.setLoading(true)
        return axios.get(`${url.value}/${payload.url}`,{
            params: payload.search,
            headers: {
                "authorization" : `Bearer ${token.value}`
            }
        }).catch(e => {
            console.log(e)
            ElMessage({
                type: 'error',
                message: e.response
            })
            if (e.response.status == 401) router.push({name:'login'})
            // console.clear()
        }).finally(()=>{loadingStore.setLoading(false)})
    } 
    
    const post = async (payload) => {
        loadingStore.setLoading(true)
        return axios.post(`${url.value}/${payload.url}`,
        payload.data,{
            headers: {
                "authorization" : `Bearer ${token.value}`
            }
        }).catch(e => {
            ElMessage({
                type: 'error',
                message: e.response.data
            })
            // console.clear()
        }).finally(()=>{
            loadingStore.setLoading(false)
        })
    } 
    
    const put = async (payload) => {
        loadingStore.setLoading(true)
        return axios.put(`${url.value}/${payload.url}`,
        payload.data,
        {
            headers: {
                "authorization" : `Bearer ${token.value}`
            }
        }).catch(e => {
            ElMessage({
                type: 'error',
                message: e.response.data
            })
            console.clear()
        }).finally(()=>{
            loadingStore.setLoading(false)
        })
    } 
    
    const remove = async (payload) => {
        loadingStore.setLoading(true)
        return axios.delete(`${url.value}/${payload.url}`,{
            headers: {
                "authorization" : `Bearer ${token.value}`
            }
        }).catch(e => {
            ElMessage({
                type: 'error',
                message: e.response.data
            })
            console.clear()
        }).finally(()=>{
            loadingStore.setLoading(false)
        })
    } 


    return {
        get,
        post,
        put,
        remove,
        url
    }

})