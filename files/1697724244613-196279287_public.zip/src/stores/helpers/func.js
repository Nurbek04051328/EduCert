export const indexMethod = (index,page,pageSize) => {
    return (page-1)*pageSize + index + 1
}
