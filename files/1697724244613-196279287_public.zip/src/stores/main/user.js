import {ref} from 'vue'
import {defineStore} from 'pinia'

import { useTokenStore } from './token'
import { apiStore } from '../helpers/axios'
import { useMenuStore } from '../menu'
import cookies from 'vue-cookies'
import router from '../../router'
import { ElMessage } from 'element-plus'

export const useUserStore = defineStore('user',()=>{
    const user = ref({})
    const tokenStore = useTokenStore()
    const api = apiStore()
    const menuStore = useMenuStore()

    const {setToken} = tokenStore
    const {setMenu} = menuStore

    const login = async (payload) => {
        api.post({
            url: 'auth/login',
            data: payload
        })
        .then(res => {
            setToken(res.data.token)
            console.log(res.data)
            user.value = res.data.user
            let {name,login} = user.value
            setMenu(res.data.user?.role)
            cookies.set('wash-user',{name, login})            
            
            router.push({name:'dashboard'})
        })
    }

    const checkUser = async () => {
        if (cookies.isKey('wash-token')){
            setToken(cookies.get('wash-token'))
            api.get({url:'auth/verif'})
            .then(res => {
                user.value = res.data
                setMenu(res.data.role)
            }).catch(error => {
                ElMessage.warning(error)
            })
        } else {
            router.push({name:'login'})
        }
    }

    const exit = () => {
        cookies.remove('wash-token')
        cookies.remove('wash-user')
        user.value = {}
        ElMessage({
            type:'warning',
            message:'Tizimdan chiqdingiz'
        })
        router.push({name:'login'})
    }

    return {
        user,
        login,
        checkUser,
        exit
    }
})