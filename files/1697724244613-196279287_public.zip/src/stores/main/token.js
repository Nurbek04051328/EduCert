import {ref} from 'vue'
import {defineStore} from 'pinia'
import cookies from 'vue-cookies'

export const useTokenStore = defineStore('token',()=>{
    const token = ref('')
    const headerToken = ref({})
    const setToken = (payload) => {
        cookies.set('wash-token',payload)
        token.value = payload
        headerToken.value = {
            'authorization':`Bearer ${token.value}`
        }
    }

    return {
        token,
        setToken,
        headerToken
    }
})